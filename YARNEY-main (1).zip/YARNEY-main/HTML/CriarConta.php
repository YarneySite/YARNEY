<?php 
/*if(Isset($_POST['subimit'])){
    print_r($_POST['nome']);
    print_r($_POST['email']);
    print_r($_POST['senha']);
}*/
include_once('config.php');

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['password'];

$result = mysqli_querry($conexao, "INSERT INTO usuarios(nome,email,senha) VALUES('$nome','$email','$senha')");
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yarney - Criação de conta</title>
    <link rel="stylesheet" href="../Styles/Header.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Anonymous+Pro:ital,wght@0,400;0,700;1,400;1,700&family=Caveat&family=Open+Sans:ital,wght@0,400;0,600;0,700;0,800;1,400&family=Poppins:wght@300;600;800&display=swap"
        rel="stylesheet">
        <link rel="stylesheet" href="../Styles/CriarConta.css">

</head>

<body>
    
    <header>
        <!--Navegar-->
        <nav class="navbar">
            <h2>YARNEY <img src="../Imagens/favicon.png" alt=""></h2>
            <!--img da logo aqui-->

            <ul>
               
                
                <li>
                    <!--Notícias-->
                    <a href="../HTML/Noticias.html">Notícias</a>
                </li>
                <li>
                    <!--Tier List-->
                    <a href="">NerdList</a>
                </li>
                <li>
                    <!--Quizzes-->
                    <a href="">Quizzes</a>
                </li>
                <li>
                    <!--Copinha-->
                    <a href="">IA</a>
                </li>

            </ul>
            <div class="search-container">
                <img id="lupa" src="../Imagens/lupa.png" alt="Lupa">
                <input type="search" name="search" id="search" placeholder="Buscar...">
            </div>


            <!-- Botão de fazer login -->
            <button class="btn-navbar"><a href="../HTML/FazerLogin.html">Fazer Login</a></button>
        </nav>

    </header>
    <main class="container">

    <!-- Título -->
    <h1>Criar Conta!</h1>
    

        <!-- Formulário -->
    <form action="CriarConta.php" method="POST">
        <div id="login">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" placeholder="Digite seu nome" class="forms" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" placeholder="Digite seu e-mail" class="forms" required>
            </div>
            <div class="form-group">
                <label for="senha">Senha:</label>
                <input id="senha" type="password" name="password" placeholder="Digite sua senha" class="forms" required>
            </div>
            <div class="form-group">
                <label for="confirme-senha">Confirme Senha:</label>
                <input id="confirme-senha" type="password" name="confirm-password" placeholder="Confirme sua senha" class="forms" required>
            </div>
            <div class="form-button ">
                <input type="submit">
                <!-- <button type="" id="btn-entrar"><a href="../HTML/Noticias.html">Entrar</a></button> -->
            </div>
        </div>

        
    </form>
    
    


    </main>

</body>

</html>
